import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';

import {ServiceService} from '../service.service'

@Component({
  selector: 'app-form',
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.css']
})
export class FormComponent implements OnInit {
 
  
  
  submitted = false;
  section: any=['A','B','C'];
  
  
  addStudent: FormGroup|any;
  router: any;
 
  
  
  constructor( private student:ServiceService,router:Router) { }

  
  
  ngOnInit(): void {

     this.addStudent=new FormGroup( {
      name: new FormControl( null ,[Validators.required]),
      email: new FormControl( null,[Validators.required] ),
      password: new FormControl( null,[Validators.required] ),
      dept: new FormControl(null,[Validators.required]),
      sec: new FormControl( null,[Validators.required] ),
    } );
    
  }
  get f() {return this.addStudent.controls}


  
  
  
 

  SaveData() {
    //console.log( this.addStudent.value );
    this.submitted=true;

    if(this.addStudent.invalid){
      return;
    }


    this.student.saveStudentData( this.addStudent.value ).subscribe( ( result ) => {
      //console.log( result );
      this.submitted = false;
      this.addStudent.reset({});


      
      
    } );
    Swal.fire({  
      position: 'top',  
      icon: 'success',  
      title: 'DATA IS SUCESSFULLY STORED',  
      
      
    })  

  }

  

  


 
 
  
 



  }

