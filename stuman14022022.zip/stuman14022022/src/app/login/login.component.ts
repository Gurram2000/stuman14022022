import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormComponent } from '../form/form.component';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import Swal from 'sweetalert2';
import { AppComponent } from '../app.component';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  
})
export class LoginComponent implements OnInit {

  registerForm: FormGroup | any;
    submitted = false;

  constructor(private formBuilder: FormBuilder,private router: Router, private appcomp: AppComponent) { }

  ngOnInit(): void {

    this.registerForm = this.formBuilder.group({
      
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]],
      
  });
  }
  get f() { return this.registerForm.controls; }

  btnClick=  () => {
    this.submitted=true;
    if(this.registerForm.invalid){
      return;
    }


    if(this.registerForm.get('email').value=="admin@gmail.com" && this.registerForm.get('password').value=="123456"){
      this.router.navigateByUrl('/home');
      
      this.appcomp.adminlogin();
    }

    else{
      alert("wrong credentials");
    }
    
   
    
    

    
};

  

}

